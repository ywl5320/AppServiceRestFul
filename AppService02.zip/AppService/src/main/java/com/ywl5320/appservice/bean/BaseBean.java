package com.ywl5320.appservice.bean;

import java.io.Serializable;

/**
 * Created by ywl5320 on 2017/10/12.
 */
public class BaseBean implements Serializable{

}
