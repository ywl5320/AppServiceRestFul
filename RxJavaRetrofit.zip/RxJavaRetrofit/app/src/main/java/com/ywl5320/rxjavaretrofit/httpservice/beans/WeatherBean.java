package com.ywl5320.rxjavaretrofit.httpservice.beans;

/**
 * Created by ywl on 2016/6/26.
 */
public class WeatherBean {
    private int status;
    private String message;
}
